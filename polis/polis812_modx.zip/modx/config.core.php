<?php
define('MODX_CORE_PATH', '/home/x/xs290050/mango-digital.ru/public_html/debug/1016-polis/modx/core/');
define('MODX_CONFIG_KEY', 'config');
?>