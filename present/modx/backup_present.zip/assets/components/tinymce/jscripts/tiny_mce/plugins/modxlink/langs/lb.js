tinyMCE.addI18n('lb.modxlink',{
    link_desc:"Insert/edit link"
});