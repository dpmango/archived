tinyMCE.addI18n('pt.modxlink',{
    link_desc:"Insert/edit link"
});