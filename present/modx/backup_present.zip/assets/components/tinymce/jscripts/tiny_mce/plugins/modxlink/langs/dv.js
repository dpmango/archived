tinyMCE.addI18n('dv.modxlink',{
    link_desc:"Insert/edit link"
});